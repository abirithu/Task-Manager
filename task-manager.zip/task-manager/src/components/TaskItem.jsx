import React from 'react';

const TaskItem = ({ task, setTasks }) => {
  const toggleComplete = () => {
    setTasks((prevTasks) =>
      prevTasks.map((t) =>
        t.id === task.id ? { ...t, completed: !t.completed } : t
      )
    );
  };

  return (
    <div className={`task-item ${task.completed ? 'completed' : ''}`}>
      <input type="checkbox" checked={task.completed} onChange={toggleComplete} />
      <div className="task-details">
        <h3>{task.title}</h3>
        <p>{task.description}</p>
      </div>
    </div>
  );
};

export default TaskItem;
