import React from "react";

const Filter = ({ filterStatus, setFilterStatus, sortBy, setSortBy }) => {
  return (
    <div className="filter-container">
      {/* Filter Tasks by Status */}
      <label>Filter: </label>
      <select value={filterStatus} onChange={(e) => setFilterStatus(e.target.value)}>
        <option value="all">All</option>
        <option value="pending">Pending</option>
        <option value="completed">Completed</option>
      </select>

      {/* Sort Tasks by Due Date or Priority */}
      <label>Sort By: </label>
      <select value={sortBy} onChange={(e) => setSortBy(e.target.value)}>
        <option value="date">Due Date</option>
        <option value="priority">Priority</option>
      </select>
    </div>
  );
};

export default Filter;
