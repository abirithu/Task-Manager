import React from "react";
import { useDrag, useDrop } from "react-dnd";

const TaskItem = ({ task, index, moveTask }) => {
  const [{ isDragging }, drag] = useDrag({
    type: "TASK",
    item: { index },
    collect: (monitor) => ({
      isDragging: monitor.isDragging(),
    }),
  });

  const [, drop] = useDrop({
    accept: "TASK",
    hover: (draggedItem) => {
      if (draggedItem.index !== index) {
        moveTask(draggedItem.index, index);
        draggedItem.index = index;
      }
    },
  });

  return (
    <div
      ref={(node) => drag(drop(node))}
      className="task-item"
      style={{ opacity: isDragging ? 0.5 : 1 }}
    >
      <p>{task.title}</p>
    </div>
  );
};

const DragDrop = ({ tasks, setTasks }) => {
  const moveTask = (fromIndex, toIndex) => {
    const updatedTasks = [...tasks];
    const [movedTask] = updatedTasks.splice(fromIndex, 1);
    updatedTasks.splice(toIndex, 0, movedTask);
    setTasks(updatedTasks);
  };

  return (
    <div className="task-list">
      {tasks.map((task, index) => (
        <TaskItem key={task.id} task={task} index={index} moveTask={moveTask} />
      ))}
    </div>
  );
};

export default DragDrop;
