import React from "react";
import Home from "./pages/Home.jsx"; // ✅ Make sure Home.jsx exists
import "./index.css"; // ✅ Ensure styles are imported
import "./styles/global.css";

const App = () => {
  return (
    <div className="app-container">
      <Home />
    </div>
  );
};

export default App;
