import React, { useState, useEffect } from "react";
import Header from "../components/Header";
import TaskForm from "../components/TaskForm";
import TaskList from "../components/TaskList";
import Filter from "../components/Filter";
import DragDrop from "../components/DragDrop";
import "../styles/global.css";

const Home = () => {
  // Load tasks from local storage or start with an empty list
  const [tasks, setTasks] = useState(() => {
    return JSON.parse(localStorage.getItem("tasks")) || [];
  });

  // State for filtering & sorting
  const [filterStatus, setFilterStatus] = useState("all");
  const [sortBy, setSortBy] = useState("date");

  // Save tasks to local storage whenever they change
  useEffect(() => {
    localStorage.setItem("tasks", JSON.stringify(tasks));
  }, [tasks]);

  // Function to add a new task
  const addTask = (task) => {
    setTasks([...tasks, { ...task, id: Date.now(), completed: false }]);
  };

  // Function to update a task (edit or mark as completed)
  const updateTask = (taskId, updatedTask) => {
    setTasks(tasks.map((task) => (task.id === taskId ? updatedTask : task)));
  };

  // Function to delete a task
  const deleteTask = (taskId) => {
    setTasks(tasks.filter((task) => task.id !== taskId));
  };

  // Filter and sort tasks based on user selection
  const filteredTasks = tasks
    .filter((task) => {
      if (filterStatus === "pending") return !task.completed;
      if (filterStatus === "completed") return task.completed;
      return true;
    })
    .sort((a, b) => {
      if (sortBy === "date") return new Date(a.dueDate) - new Date(b.dueDate);
      if (sortBy === "priority") return b.priority - a.priority; // Higher priority first
      return 0;
    });

  return (
    <div className="home-container">
      <Header />
      <TaskForm addTask={addTask} />
      <Filter
        filterStatus={filterStatus}
        setFilterStatus={setFilterStatus}
        sortBy={sortBy}
        setSortBy={setSortBy}
      />
      <DragDrop tasks={filteredTasks} setTasks={setTasks} />
      <TaskList tasks={filteredTasks} updateTask={updateTask} deleteTask={deleteTask} />
    </div>
  );
};

export default Home;
